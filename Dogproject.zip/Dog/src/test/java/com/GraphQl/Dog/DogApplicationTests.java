package com.GraphQl.Dog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogApplicationTests {

	@Test
	void contextLoads() {
	}

}
